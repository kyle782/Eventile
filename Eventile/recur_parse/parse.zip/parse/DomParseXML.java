package com.parse;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class DomParseXML {

	public static String getTagRrules(String event_id) throws IOException,
			ParserConfigurationException, SAXException {

		String link = "http://api.evdb.com/rest/events/get?id=" + event_id
				+ "&app_key=8bxzXBxmQHqBqgJX&include=instances";

		URL url = new URL(link);
		URLConnection conn = url.openConnection();

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.parse(conn.getInputStream());

		NodeList rrules = doc.getElementsByTagName("rrules");

		Element rrule = (Element) rrules.item(0);
		if (rrule != null) {
			System.out.println("rrule: " + rrule.getTextContent());
			return rrule.getTextContent();
		} else {
			System.out.println("rrule is null");
			return null;

		}
	}

}
