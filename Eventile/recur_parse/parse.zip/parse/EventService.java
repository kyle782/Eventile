package com.parse;

import java.io.IOException;
import java.net.MalformedURLException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.evdb.javaapi.EVDBAPIException;
import com.evdb.javaapi.EVDBRuntimeException;
import com.evdb.javaapi.data.Event;
import com.evdb.javaapi.data.SearchResult;
import com.evdb.javaapi.data.request.EventSearchRequest;
import com.evdb.javaapi.operations.EventOperations;

public class EventService {

	public SearchResult searchEvents(EventSearchRequest esr) {
		EventOperations eo = new EventOperations();

		SearchResult sr = null;
		try {
			sr = eo.search(esr);
		} catch (EVDBRuntimeException var) {
			System.out.println("Opps got runtime an error...");
		} catch (EVDBAPIException var) {
			System.out.println("Opps got runtime an error...");
		}
		return sr;
	}

	public void insertEvents(SearchResult sr) throws EVDBRuntimeException,
			EVDBAPIException, MalformedURLException, IOException,
			ParserConfigurationException, SAXException, SQLException,
			InstantiationException, IllegalAccessException,
			ClassNotFoundException {
		int num = sr.getTotalItems();
		EventsDAO dao = new EventsDAO();

		// insert event into events table

		for (int i = 0; i < num; i++) {
			Event e = getEventBySeid(sr, i);
			String recur = sr.getEvents().get(i).getRecurString();
			dao.insertEvent(e);
		}
	}

	public Event getEventBySeid(SearchResult sr, int index)
			throws EVDBRuntimeException, EVDBAPIException {
		EventOperations eo = new EventOperations();
		Event e = eo.get(sr.getEvents().get(index).getSeid());
		return e;
	}

	public static String getDateCollection(Event e) throws IOException,
			ParserConfigurationException, SAXException {
		String date_collection = "";

		String rrule = DomParseXML.getTagRrules(e.getSeid());
		// String rrule = "FREQ=YEARLY;BYMONTH=12;BYDAY=3MO;COUNT=5";
		// String rrule ="FREQ=WEEKLY;INTERVAL=3;BYDAY=MO,WE;COUNT=5";
		// String rrule="FREQ=MONTHLY;INTERVAL=4;BYMONTHDAY=20;COUNT=5";
		// String rrule="FREQ=MONTHLY;INTERVAL=4;BYDAY=3MO;COUNT=5";
		// String rrule="FREQ=YEARLY;BYMONTH=12;COUNT=5";
		// String rrule="FREQ=YEARLY;BYMONTH=12;BYDAY=3MO;COUNT=5";

		String starttime = e.getStartTime().toString();
		
		String mins=String.valueOf(e.getStartTime().getMinutes());
		if(mins.length()<2)
			mins=mins+"0";
		
		String time_of_day = e.getStartTime().getHours() + ":"
				+ mins;

		if (time_of_day.length() < 3)
			time_of_day = " ";

		String currtime = new SimpleDateFormat("yyyyMMdd").format(Calendar
				.getInstance().getTime());

		System.out.println("time of day=" + time_of_day);

		// it is a one-time non-recuring event
		if (rrule == null) {

			date_collection = starttime;
			System.out.println("step 1: " + date_collection);

			// it is a recurs event
		} else if (rrule != null) {

			rrule = rrule.trim();
			String FREQ = DateService.getValueByName(rrule, "FREQ");
			String INTERVAL = DateService.getValueByName(rrule, "INTERVAL");
			String COUNT = DateService.getValueByName(rrule, "COUNT");
			String UNTIL = DateService.getValueByName(rrule, "UNTIL");

			if (UNTIL == null)
				UNTIL = "20201212";
			if (INTERVAL == null)
				INTERVAL = "1";
			if (COUNT == null)
				COUNT = "50";

			System.out.println("paras: freq=" + FREQ + "|interval=" + INTERVAL
					+ "|count=" + COUNT + "|until=" + UNTIL);

			// recurs daily
			if (FREQ.equals("DAILY")) {

				date_collection = DateService.getDateDaily(currtime, UNTIL,
						INTERVAL, COUNT, time_of_day);
				System.out.println("step 3: " + date_collection);

			} else if (FREQ.equals("WEEKLY")) {

				date_collection = DateService.getDateWeekly(currtime, UNTIL,
						INTERVAL, COUNT, rrule, time_of_day);

				System.out.println("step 4: " + date_collection);

			} else if (FREQ.equals("MONTHLY")) {

				date_collection = DateService.getDateMonthly(currtime, UNTIL,
						INTERVAL, COUNT, rrule, time_of_day);

				System.out.println("step 5: " + date_collection);

			} else if (FREQ.equals("YEARLY")) {

				date_collection = DateService.getDateYearly(currtime, UNTIL,
						INTERVAL, COUNT, rrule, time_of_day);
				System.out.println("step 6: " + date_collection);

			}
		}
		return date_collection;
	}

}
