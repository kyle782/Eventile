package com.parse;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.tidy.Tidy;
import org.xml.sax.SAXException;

import com.evdb.javaapi.data.Event;

public class EventsDAO {
	Connection conn = null;
	ResultSet rs = null;
	PreparedStatement ps = null;

	public void insertEvent(Event e) throws MalformedURLException, IOException,
			ParserConfigurationException, SAXException, SQLException,
			InstantiationException, IllegalAccessException,
			ClassNotFoundException {

		String sql = "insert into events(seid, title, description, "
				+ "ischarge, organization,url,venue,eventtype, images,datecollection ) "
				+ "values(?,?,?,?,?,?,?,?,?,?)";

		conn = DBConnection.getConnection();
		ps = conn.prepareStatement(sql);
		System.out.println();
		ps.setString(1, e.getSeid());
		ps.setString(2, e.getTitle());
		ps.setString(3,  e.getDescription());
		ps.setBoolean(4, e.isFree());
		ps.setString(5, e.getVenueName());
		ps.setString(6, e.getURL());
		ps.setString(7, e.getVenueAddress());
		ps.setString(8, e.getCategories().get(0).getName());
		String image_url = "";
		if (!e.getImages().isEmpty())
			image_url = e.getImages().get(0).getUrl();
		ps.setString(9, image_url);
		ps.setString(10, EventService.getDateCollection(e));

		// process image
		ps.executeUpdate();

	}
}
