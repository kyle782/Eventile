package com.parse;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.evdb.javaapi.EVDBAPIException;
import com.evdb.javaapi.EVDBRuntimeException;
import com.evdb.javaapi.data.Event;
import com.evdb.javaapi.data.SearchResult;
import com.evdb.javaapi.data.request.EventSearchRequest;
import com.evdb.javaapi.operations.EventOperations;
import com.evdb.javaapi.test.APIConfigurationData;

public class Test_Case {

	/**
	 * @param args
	 * @throws EVDBAPIException
	 * @throws EVDBRuntimeException
	 * @throws SAXException
	 * @throws ParserConfigurationException
	 * @throws IOException
	 */
	public static void main(String[] args) throws EVDBRuntimeException,
			EVDBAPIException, IOException, ParserConfigurationException,
			SAXException {
		APIConfigurationData.loadAPIConfigurationDataFromPropertyFile();

		EventSearchRequest esr = new EventSearchRequest();
		esr.setLocation("Pittsburgh,PA");
		esr.setKeywords("exhibition");

		esr.setDateRange("2013052900-2013061200");

		EventService es = new EventService();
		EventOperations eo = new EventOperations();

		SearchResult sr = null;
		sr = eo.search(esr);

		System.out.println("total: " + sr.getTotalItems());

		Event e1 = sr.getEvents().get(7);
		System.out.println(e1.getSeid());
		System.out.println(e1.getTitle());
		System.out.println(e1.getRecurString());
		System.out.println("START TIME"+e1.getStartTime());

		Event e = eo.get("E0-001-057450210-5@2013052910");
		System.out.println("date_collections"
				+ es.getDateCollection(e).toString());
	}
}
