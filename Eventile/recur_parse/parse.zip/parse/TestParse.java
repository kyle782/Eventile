package com.parse;

import java.io.IOException;
import java.net.MalformedURLException;
import java.sql.SQLException;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.evdb.javaapi.EVDBAPIException;
import com.evdb.javaapi.EVDBRuntimeException;
import com.evdb.javaapi.data.Event;
import com.evdb.javaapi.data.SearchResult;
import com.evdb.javaapi.data.request.EventSearchRequest;
import com.evdb.javaapi.operations.EventOperations;
import com.evdb.javaapi.test.APIConfigurationData;

public class TestParse {

	public static void main(String[] args) throws ParserConfigurationException,
			SAXException, SQLException, InstantiationException,
			IllegalAccessException, ClassNotFoundException {

		APIConfigurationData.loadAPIConfigurationDataFromPropertyFile();
		System.out.println("-----test1-----");

		EventSearchRequest esr = new EventSearchRequest();
		esr.setLocation("Pittsburgh,PA");
		esr.setKeywords("exhibition");
		esr.setDateRange("2013052900-2013061200");
		esr.setCategory("");
		esr.setPageSize(20);
		esr.setPageNumber(1);
		// These 2 lines will set the timeout to 60 seconds.Normally not needed
		// Unless you are using Google App Engine
		esr.setConnectionTimeout(60000); // Used with Google App Engine only
		esr.setReadTimeout(60000); // Used with Google App Engine only

		EventService es = new EventService();

		try {

			es.insertEvents(es.searchEvents(esr));

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (EVDBRuntimeException e) {
			e.printStackTrace();
		} catch (EVDBAPIException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
