package com.parse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBConnection {
	static Connection conn = null;
	ResultSet rs = null;
	PreparedStatement psmnt = null;

	public static Connection getConnection() throws InstantiationException,
			IllegalAccessException, ClassNotFoundException, SQLException {
		if (conn != null)
			return conn;
		else {
			Class.forName("com.mysql.jdbc.Driver").newInstance();

			conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/Eventur?useUnicode=true&characterEncoding=gb2312", "root", "");
			return conn;
		}
	}
}
