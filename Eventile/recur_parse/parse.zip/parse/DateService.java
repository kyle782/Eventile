package com.parse;

import java.text.DateFormatSymbols;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Set;

public class DateService {

	// get dates when FREQ = DAILY
	public static String getDateDaily(String STARTTIME, String UNTIL,
			String INTERVAL, String COUNT, String time_of_day) {

		ArrayList<Integer> end_t = processTime(UNTIL);

		int repeats = Integer.parseInt(COUNT);

		ArrayList<Integer> begin_t = processTime(STARTTIME);

		String date_collection = "";
		Calendar c_begin = new GregorianCalendar();
		Calendar c_end = new GregorianCalendar();
		DateFormatSymbols dfs = new DateFormatSymbols();
		String[] weeks = dfs.getWeekdays();

		c_begin.set(begin_t.get(0), begin_t.get(1) - 1, begin_t.get(2));
		c_end.set(end_t.get(0), end_t.get(1) - 1, end_t.get(2));

		// includes the last day
		c_end.add(Calendar.DAY_OF_YEAR, 1);

		while (c_begin.before(c_end) && repeats > 0) {

			date_collection += "| "
					+ new java.sql.Date(c_begin.getTime().getTime()) + " "
					+ weeks[c_begin.get(Calendar.DAY_OF_WEEK)] + " "
					+ time_of_day + " ";

			c_begin.add(Calendar.DAY_OF_YEAR, Integer.parseInt(INTERVAL));
			repeats--;
		}
		return date_collection;
	}

	// get dates when FREQ = WEEKLY
	public static String getDateWeekly(String STARTTIME, String UNTIL,
			String INTERVAL, String COUNT, String rrule, String time_of_day) {

		ArrayList<Integer> end_t = processTime(UNTIL);
		int repeats = Integer.parseInt(COUNT);

		String BYDAY = getValueByName(rrule, "BYDAY");

		if (BYDAY == null)
			BYDAY = "MO,TU,WE,TH,FR,SA,SU";

		ArrayList<Integer> begin_t = processTime(STARTTIME);

		String date_collection = "";
		Calendar c_begin = new GregorianCalendar();
		Calendar c_end = new GregorianCalendar();
		DateFormatSymbols dfs = new DateFormatSymbols();
		String[] weeks = dfs.getWeekdays();

		c_begin.set(begin_t.get(0), begin_t.get(1) - 1, begin_t.get(2));
		c_end.set(end_t.get(0), end_t.get(1) - 1, end_t.get(2));

		c_end.add(Calendar.DAY_OF_YEAR, 1);

		Set<String> we = processByDayWeekly(BYDAY);

		while (c_begin.before(c_end) && repeats > 0) {

			if (we.contains(weeks[c_begin.get(Calendar.DAY_OF_WEEK)].substring(
					0, 2).toUpperCase())) {

				date_collection += "| "
						+ new java.sql.Date(c_begin.getTime().getTime()) + " "
						+ weeks[c_begin.get(Calendar.DAY_OF_WEEK)] + " "
						+ time_of_day + " ";
				repeats--;
			}
			// scan each day of week
			c_begin.add(Calendar.DAY_OF_YEAR, 1);

			// skip to weeks in interval
			if (weeks[c_begin.get(Calendar.DAY_OF_WEEK)].equals("Sunday"))
				c_begin.add(Calendar.DAY_OF_YEAR,
						(Integer.parseInt(INTERVAL) - 1) * 7);

		}

		return date_collection;
	}

	// get dates when FREQ = MONTHLY
	public static String getDateMonthly(String STARTTIME, String UNTIL,
			String INTERVAL, String COUNT, String rrule, String time_of_day) {

		ArrayList<Integer> end_t = processTime(UNTIL);

		int repeats = Integer.parseInt(COUNT);

		String BYDAY = getValueByName(rrule, "BYDAY");

		String BYMONTHDAY = getValueByName(rrule, "BYMONTHDAY");

		ArrayList<Integer> begin_t = processTime(STARTTIME);

		String date_collection = "";
		Calendar c_begin = new GregorianCalendar();
		Calendar c_end = new GregorianCalendar();
		DateFormatSymbols dfs = new DateFormatSymbols();
		String[] weeks = dfs.getWeekdays();

		c_begin.set(begin_t.get(0), begin_t.get(1) - 1, begin_t.get(2));
		c_end.set(end_t.get(0), end_t.get(1) - 1, end_t.get(2));

		// includes the last day
		c_end.add(Calendar.DAY_OF_YEAR, 1);

		if (BYMONTHDAY != null) {

			Calendar current = new GregorianCalendar();
			// set the right day of month
			current.set(Calendar.DAY_OF_MONTH, Integer.parseInt(BYMONTHDAY));

			while (current.before(c_end) && repeats > 0) {

				date_collection += "| "
						+ new java.sql.Date(current.getTime().getTime())
								.toString() + " "
						+ weeks[current.get(Calendar.DAY_OF_WEEK)] + " "
						+ time_of_day + " ";
				repeats--;

				current.add(Calendar.MONTH, Integer.parseInt(INTERVAL));

			}
		} else if (BYDAY != null) {

			Calendar current = new GregorianCalendar();

			while (current.before(c_end) && repeats > 0) {

				// the first day of current month
				current.set(Calendar.DAY_OF_MONTH, Calendar.getInstance()
						.getActualMinimum(Calendar.DAY_OF_MONTH));

				// move to the right week
				current.add(Calendar.WEEK_OF_MONTH, Integer.parseInt(BYDAY
						.substring(0, BYDAY.length() - 2)));

				// move to right day
				current.set(Calendar.DAY_OF_WEEK, mappingWeek(BYDAY));

				// add this day to dates
				date_collection += "| "
						+ new java.sql.Date(current.getTime().getTime())
								.toString() + " "
						+ weeks[current.get(Calendar.DAY_OF_WEEK)] + " "
						+ time_of_day + " ";
				repeats--;

				// skip to interval months
				current.add(Calendar.MONTH, Integer.parseInt(INTERVAL));

			}

		} else {
			System.out.println("getDateMonthly error | invalid input format");
		}

		return date_collection;
	}

	// get dates when FREQ = YEARLY
	public static String getDateYearly(String STARTTIME, String UNTIL,
			String INTERVAL, String COUNT, String rrule, String time_of_day) {

		ArrayList<Integer> end_t = processTime(UNTIL);

		int repeats = Integer.parseInt(COUNT);

		String BYDAY = getValueByName(rrule, "BYDAY");

		String BYMONTH = getValueByName(rrule, "BYMONTH");

		ArrayList<Integer> begin_t = processTime(STARTTIME);

		String date_collection = "";
		Calendar c_begin = new GregorianCalendar();
		Calendar c_end = new GregorianCalendar();
		DateFormatSymbols dfs = new DateFormatSymbols();
		String[] weeks = dfs.getWeekdays();

		c_begin.set(begin_t.get(0), begin_t.get(1) - 1, begin_t.get(2));
		c_end.set(end_t.get(0), end_t.get(1) - 1, end_t.get(2));

		// includes the last day
		c_end.add(Calendar.DAY_OF_YEAR, 1);

		if (BYMONTH != null) {

			if (BYDAY == null) {

				while (c_begin.before(c_end) && repeats > 0) {

					// move to the right month
					c_begin.set(Calendar.MONTH, Integer.parseInt(BYMONTH) - 1);

					date_collection += "| "
							+ new java.sql.Date(c_begin.getTime().getTime())
									.toString() + " "
							+ weeks[c_begin.get(Calendar.DAY_OF_WEEK)] + " "
							+ time_of_day + " ";
					repeats--;

					// skip to interval year
					c_begin.add(Calendar.YEAR, Integer.parseInt(INTERVAL));
				}
			} else {

				Calendar current = new GregorianCalendar();

				while (current.before(c_end) && repeats > 0) {

					// move to the right month
					current.set(Calendar.MONTH, Integer.parseInt(BYMONTH) - 1);

					// move to the right week
					current.set(Calendar.WEEK_OF_MONTH, Integer.parseInt(BYDAY
							.substring(0, BYDAY.length() - 2)));

					// move to right day
					current.set(Calendar.DAY_OF_WEEK, mappingWeek(BYDAY));

					// add this day to dates
					date_collection += "| "
							+ new java.sql.Date(current.getTime().getTime())
									.toString() + " "
							+ weeks[current.get(Calendar.DAY_OF_WEEK)] + " "
							+ time_of_day + " ";
					repeats--;

					// skip to interval year
					current.add(Calendar.YEAR, Integer.parseInt(INTERVAL));

				}

			}
		} else {
			System.out.println("getDateYearly error | invalid input format");
		}

		return date_collection;
	}

	public static Set<String> processByDayWeekly(String BYDAY) {

		Set<String> results = new HashSet<String>();

		while (BYDAY.indexOf(",") != -1) {
			String we = BYDAY.substring(0, 2);
			results.add(we);
			BYDAY = BYDAY.substring(3);
		}
		results.add(BYDAY.substring(0, 2));

		System.out.println("BYDAY=" + results.toString());
		return results;
	}

	public static ArrayList<Integer> processTime(String time) {
		ArrayList<Integer> result = new ArrayList<Integer>();

		int year = Integer.parseInt(time.substring(0, 4));
		int month = Integer.parseInt(time.substring(4, 6));
		int day = Integer.parseInt(time.substring(6));

		System.out.println(year + "|" + month + "|" + day);

		result.add(year);
		result.add(month);
		result.add(day);
		return result;
	}

	public static String getValueByName(String rrule, String name) {

		int index = rrule.indexOf(name + "=");

		if (index == -1) {
			System.out.println("there is no this property in rrule");
			return null;
		} else {
			String rrule_left = rrule.substring(index + name.length() + 1);

			// System.out.println("rrule_left=" + rrule_left);

			int semicolon = rrule_left.indexOf(";");
			if (semicolon == -1)
				return rrule_left;
			else {
				return rrule_left.substring(0, semicolon);
			}
		}
	}

	public static int mappingWeek(String BYDAY) {
		String we = BYDAY.substring(BYDAY.length() - 2);
		if (we.equals("MO"))
			return Calendar.MONDAY;
		else if (we.equals("TU"))
			return Calendar.TUESDAY;
		else if (we.equals("WE"))
			return Calendar.WEDNESDAY;
		else if (we.equals("TH"))
			return Calendar.FRIDAY;
		else if (we.equals("SA"))
			return Calendar.SATURDAY;
		else if (we.equals("SU"))
			return Calendar.SUNDAY;
		else {
			System.out.println("mapping Week error | date service");
			return -1;
		}
	}

}
